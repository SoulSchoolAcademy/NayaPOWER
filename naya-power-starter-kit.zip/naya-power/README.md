# NAYA POWER — STARTER KIT
### A working, minimal implementation of the enforcement layer

This is deliberately small. After three rounds of review, the consistent finding
was: the philosophy is strong, the enforcement was aspirational. So this kit
does not add new categories or protocols. It takes the five highest-leverage
ideas from the reviews and makes them **real** — a validator that actually
rejects bad claims, not a schema that describes what good claims would look like.

## WHAT'S HERE

```
00-CONSTITUTION/CORE.md          The ten laws + the two precedence stacks, in full
01-LAWS/evidence-model.yaml      The E0–E4 tiers, machine-readable
01-LAWS/reversibility-tiers.yaml The L1–L3 tiers + the always-L3 safeguard list
02-TEMPLATES/smart-note.json     Schema for a persistent memory entry
02-TEMPLATES/completion-claim.json  Schema every substantive answer should fill
03-RUNTIME/validator.py          WORKING code. Actually rejects bad claims. Tested.
04-ACTIVATION/naya-power-activation.md  Copy-paste prompt for any AI, no repo needed
```

## HOW TO USE IT TODAY, WITH NO SETUP

1. Open `04-ACTIVATION/naya-power-activation.md`.
2. Copy the block into the start of a chat with any AI.
3. That's it — you're running Naya Power's core laws in that session.

## HOW TO USE THE ENFORCEMENT LAYER

The validator is real, runnable Python — not pseudocode:

```bash
python3 03-RUNTIME/validator.py '{"claim": "...", "evidence_tier": "E3", ...}'
```

It will reject:
- a claim that says "verified" or "confirmed" without evidence_tier ≥ E2 and a
  populated test_reference
- an action matching the always-L3 list (delete, publish, pay, deploy, send to
  multiple people, change access) that's been classified as L1/L2 instead of L3
- an L3 action with no authorization confirmed

Wire it into a GitHub Action to run automatically on any commit that adds a note
or completion record, so violations get caught before merge, not after.

## WHAT TO BUILD NEXT — IN ORDER

Resist the urge to add more categories before these are solid. In priority order:

1. **Get the validator running in CI** (GitHub Actions) so it's enforced on every
   commit, not just when someone remembers to run it by hand.
2. **Build the alias/relationship layer for Smart Notes** — the retrieval design
   from the earlier review (alias match → relationship graph → temporal
   narrowing → semantic search as last resort, not first).
3. **Build the Restore Context algorithm** as actual code — supersession
   checking, conflict flagging, not just a described process.
4. **Only after 1–3 are real**: expand into Modes, Nitro, Personality, and the
   rest of the original ten protocols. They're valuable, but they're decoration
   on a foundation that needs to be load-bearing first.

## THE ONE PRINCIPLE TO HOLD ONTO

A rule stated in prose is a hope. A rule enforced by something with teeth is a
guarantee. Every time this system grows, ask which one you're adding.
