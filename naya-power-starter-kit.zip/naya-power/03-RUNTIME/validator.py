#!/usr/bin/env python3
"""
NAYA POWER VALIDATOR
Enforces the evidence and reversibility laws against a completion-claim object.

This is the difference between "a rule the AI is trusted to remember" and
"a rule that structurally can't be violated without the violation being visible."

Usage:
    python validator.py claim.json
    python validator.py '{"claim": "...", "evidence_tier": "E3", ...}'

Exit code 0 = passes. Exit code 1 = REJECTED, with reasons printed.

Wire this into a GitHub Action (see 06-TESTS/) to run automatically on any
commit that adds a Smart Note or completion record, or run it by hand /
have the AI run it against its own claim before presenting a final answer.
"""

import json
import sys
from datetime import datetime, timezone

TIERS_REQUIRING_TEST_REFERENCE = {"E2", "E3", "E4"}
VALID_TIERS = {"E0", "E1", "E2", "E3", "E4"}
VALID_REVERSIBILITY = {"L1", "L2", "L3"}

# Keep this in sync with 01-LAWS/reversibility-tiers.yaml.
# Duplicated here deliberately: the validator must not depend on successfully
# parsing a separate YAML file to enforce the single most safety-critical rule.
ALWAYS_L3_KEYWORDS = [
    "delete", "deletion", "remove permanently",
    "send to all", "broadcast", "mass email", "post publicly",
    "payment", "transaction", "charge", "invoice",
    "deploy", "production", "publish",
    "grant access", "change permission", "revoke access",
]


def fail(reasons):
    print("REJECTED — this claim does not pass Naya Power validation.\n")
    for r in reasons:
        print(f"  ✗ {r}")
    print("\nFix the claim (or the underlying work) before presenting it as complete.")
    sys.exit(1)


def validate(claim: dict):
    reasons = []

    # --- Required fields present at all ---
    required = [
        "claim", "evidence_tier", "assumptions_made",
        "what_was_not_checked", "reversibility_tier", "authorization_obtained",
    ]
    for field in required:
        if field not in claim:
            reasons.append(f"Missing required field: '{field}'. "
                            f"An absent field is not a pass — it's an unfilled claim.")

    if reasons:
        fail(reasons)  # can't check the rest meaningfully without these

    # --- Evidence tier validity ---
    tier = claim["evidence_tier"]
    if tier not in VALID_TIERS:
        reasons.append(f"evidence_tier '{tier}' is not one of {sorted(VALID_TIERS)}.")

    # --- Law 6: E2+ requires an actual test reference ---
    if tier in TIERS_REQUIRING_TEST_REFERENCE:
        ref = claim.get("test_reference")
        if not ref or ref in ("null", "None", ""):
            reasons.append(
                f"evidence_tier is '{tier}' but no test_reference was provided. "
                f"'{tier}' requires evidence something was actually run and observed — "
                f"a claim can't self-certify at this tier."
            )

    # --- Claim language must match tier (basic keyword check) ---
    strong_words = ["verified", "confirmed", "production-safe", "tested and confirmed"]
    claim_text = claim.get("claim", "").lower()
    if tier in ("E0", "E1") and any(w in claim_text for w in strong_words):
        reasons.append(
            f"The claim text uses strong verification language ('{[w for w in strong_words if w in claim_text][0]}') "
            f"but evidence_tier is only '{tier}'. Wording must not overclaim beyond the disclosed tier."
        )

    # --- Reversibility tier validity + the always-L3 safeguard ---
    rev = claim["reversibility_tier"]
    if rev not in VALID_REVERSIBILITY:
        reasons.append(f"reversibility_tier '{rev}' is not one of {sorted(VALID_REVERSIBILITY)}.")

    matched_l3_keywords = [k for k in ALWAYS_L3_KEYWORDS if k in claim_text]
    if matched_l3_keywords and rev != "L3":
        reasons.append(
            f"The claim mentions '{matched_l3_keywords[0]}', which matches the always-L3 list, "
            f"but reversibility_tier is '{rev}', not 'L3'. Per the misclassification safeguard, "
            f"this must be re-classified as L3 and requires explicit authorization."
        )

    # --- L3 requires authorization ---
    if rev == "L3" and claim.get("authorization_obtained") not in ("true", True):
        reasons.append(
            "reversibility_tier is L3 (irreversible/high-consequence) but "
            "authorization_obtained is not confirmed true. L3 actions cannot "
            "proceed without explicit human authorization."
        )

    if reasons:
        fail(reasons)

    print("PASSED — claim is structurally sound.")
    print(f"  Evidence tier: {tier}")
    print(f"  Reversibility: {rev}")
    print(f"  Assumptions disclosed: {len(claim.get('assumptions_made', []))}")
    print(f"  Not checked: {len(claim.get('what_was_not_checked', []))}")
    return True


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python validator.py <claim.json | '<json string>'>")
        sys.exit(2)

    arg = sys.argv[1]
    try:
        if arg.strip().startswith("{"):
            data = json.loads(arg)
        else:
            with open(arg) as f:
                data = json.load(f)
    except (json.JSONDecodeError, FileNotFoundError) as e:
        print(f"Could not parse input: {e}")
        sys.exit(2)

    validate(data)
