# NayaNET Living Design Standard V2 — Correction and Proof Packet

**Status:** CANDIDATE / visual teaching specimen, **not** ratified design law, not deployed Hub, not independent production acceptance.

## In a nutshell
A high-quality NayaNET interface must feel beautiful **and be instantly understandable**. Every human message explains the result before exposing technical evidence. Colors are chosen to separate ideas, not decorate them. A leader checks the actual rendered page before anyone else has to point out simple defects.

## Feedback converted into specific design rules

| Director's observation | V2 correction | Future acceptance |
|---|---|---|
| Purple-purple-purple and repeated reds | Explicit 5-jewel and bullet color sequences, no immediate duplicate; parent semantic color supplies every gem | Assert computed CSS for each jewel; visually inspect row neighbors |
| Too many gold/yellow/green shades close together | Separate jewel families spatially and by hue; five signature jewels centered with wide gaps | Reviewed hue sequence plus visual judgment; no near-twin neighbors in content clusters |
| Technical-language-first reports | Human-language example: what works, what still needs proof, what happens next; link to real learning test | Child-readable point first; exact evidence in link, not injected into paragraph |
| Gray, small body text | White base at 18px, section headings 24px+, 14px secondary labels | CSS computed type + mobile screenshot + readability review |
| Wrong N logo | Actual embedded NayaNET mark extracted from Director-supplied `report.html` | Image loaded at desktop/mobile; exact uploaded logo should be cross-checked |
| Crowded 5 jewels | One centered specimen with 5 semantically lit gems, independent breathing room | Render at 1440/768/390/320 and inspect |
| Dense paragraph blocks / boring purple numbers | Five spaced jewel-led propositions and six distinct quality-gate gems | Separation measurable; visual clarity independently accepted |
| Text colliding with buttons and duplicate labels | Responsive flex/grid, content wraps, buttons >=44px, functioning accessible controls | No horizontal overflow; screenshot and interaction checks; independent overlap review |
| Self-score unsupported | No claim of 9/10 or production readiness; explicitly demo-only | Own screenshot review + separate independent design and accessibility acceptance |

## Source fidelity
- `index(4).html` — layered intelligence, ambient dark field.
- `reports(2).html` — elegant editorial report, faceted jewel bullets, shadow/elevation.
- `spaces(2).html` — shared black chrome and visible idle light.
- `connections-10.html` — warmth, native serif light, people-oriented semantics.
- `connect(2).html` — semantic faceted source gems / real-door contrast.
- `mail(2).html` — touchable pill controls.
- `ledger(2).html` — truth-labeled atmospheric live metaphor (no simulated live events in this specimen).
- `today(2).html` — token and keyboard/reduced-motion pattern.
- `start(1).html` — human invitation and progress sequence.
- `report.html` — director-provided real NayaNET N mark.
- Design Code PDFs and Agent Briefing — source philosophy and design laws; these are not all formally ratified, so the canonical Hub/Brain design contracts continue to govern actual production.

## Verified in this workspace
- Rendered with Chromium at viewport widths: 1440, 1024, 768, 390 and 320 px.
- No horizontal overflow, all supplied images load, no JavaScript exceptions, baseline body computed at 18px, buttons at least 44px tall.
- Functional demo: button, save/unsave, room-selection content update.
- Exact computed CSS five jewel colors: `#9d75ff`, `#55b9ee`, `#55e39a`, `#e8b64c`, `#ed58cd`; all individually illuminated after catching and repairing a purple-default CSS bug **before delivery**.
- Five human bullet hues are unique with minimum adjacent gap ~51.6° in HSV hue metric; human visual judgment still required for perceived color similarity.
- Mobile screenshot at narrow 320px; zoom not disabled; reduced motion rule provided.

## Not proven
Full WCAG audit; screen reader pass; localization; cross-browser behavior beyond Chromium; external image/font networks; production backend integration; actual persistence; independent designer score; cold-builder reuse of rule; canonical rule ratification. **Code passing tests does not mean the visual design earned 10/10.**

## Next necessary action
Naya 2 and independent designer compare V2 rendered artifact to the real Reports, Spaces, Hub, and Connections in the provided HTML. Challenge semantic color spacing, text proportion, nav, official mark and human clarity. Retain only independently accepted exemplars and implement in ONE current Hub chassis and governed design code. Do not silently promote candidate to machine law.
