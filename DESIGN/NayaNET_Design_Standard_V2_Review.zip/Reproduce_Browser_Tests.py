from playwright.sync_api import sync_playwright
from pathlib import Path
import json, colorsys, math
SOURCE=Path('/mnt/data/NayaNET_Living_Design_Standard_V2.html').read_text()
out=Path('/mnt/data/naya_v2_render');out.mkdir(exist_ok=True)
def hue(hexcode):
 h=hexcode.lstrip('#');r,g,b=[int(h[i:i+2],16)/255 for i in (0,2,4)];return colorsys.rgb_to_hsv(r,g,b)[0]*360
results=[]
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 for width,height in [(1440,900),(1024,768),(768,1024),(390,844),(320,700)]:
  page=browser.new_page(viewport={'width':width,'height':height},device_scale_factor=1,reduced_motion='reduce')
  errors=[];page.on('pageerror',lambda exc:errors.append(str(exc)))
  page.set_content(SOURCE,wait_until='domcontentloaded')
  page.screenshot(path=str(out/f'standard_{width}.png'),full_page=True)
  box=page.evaluate('''() => ({vw:innerWidth, sw:document.documentElement.scrollWidth, bodySize:getComputedStyle(document.body).fontSize,
  hero:document.querySelector('h1').getBoundingClientRect().width,
  logoLoaded:[...document.querySelectorAll('img')].every(x=>x.complete&&x.naturalWidth>0),
  buttons:[...document.querySelectorAll('.btn')].map(x=>({w:Math.round(x.getBoundingClientRect().width),h:Math.round(x.getBoundingClientRect().height),txt:x.textContent.trim()})),
  rooms:[...document.querySelectorAll('.room')].map(x=>({w:Math.round(x.getBoundingClientRect().width),h:Math.round(x.getBoundingClientRect().height)})),
  critical:[...document.querySelectorAll('h1,h2,h3,p')].filter(x=>{let r=x.getBoundingClientRect(); return r.width>innerWidth+5 || r.right>innerWidth+5 || r.left < -3 }).map(x=>x.textContent.slice(0,35))})''')
  page.locator('#demo').click();localmsg=page.locator('#toast').inner_text()
  page.locator('#second').click(); saved=page.locator('#second').inner_text()
  page.locator('button[data-room="grow"]').click(); room=page.locator('#room-title').inner_text()
  pal=page.eval_on_selector_all('.bullet', '(els) => els.map(x=>x.dataset.accent)')
  # Regression: final computed jewel hue must equal its own parent; CSS fallback must NOT force purple.
  gem_pairs=page.eval_on_selector_all('.gemitem', '(els)=>els.map(x=>({desired:getComputedStyle(x).getPropertyValue("--c").trim(),actual:getComputedStyle(x.querySelector(".jewel")).getPropertyValue("--c").trim()}))')
  assert len(gem_pairs)==5 and all(x['desired']==x['actual'] for x in gem_pairs), gem_pairs
  assert len(set(x['actual'] for x in gem_pairs))==5,gem_pairs
  # The CSS pseudo-element must actually render each distinct jewel color in the browser.
  rendered_gems=page.eval_on_selector_all('.gemitem', '(els)=>els.map(x=>getComputedStyle(x.querySelector(".jewel"),"::before").backgroundImage)')
  assert len(set(rendered_gems))==5, rendered_gems
  assert len(pal)==len(set(pal)), 'repeating bullet jewels'
  assert box['sw']<=width+1,(width,box['sw'])
  assert not errors,errors
  assert box['logoLoaded'], 'logo not loaded'
  assert box['bodySize']=='18px'
  assert 'local design' in localmsg
  assert 'Saved in this preview' in saved
  assert room=='Smart Grow'
  assert not box['critical'],box['critical']
  assert all(b['h']>=44 for b in box['buttons'])
  dist=[round(min(abs(hue(pal[i])-hue(pal[i+1])),360-abs(hue(pal[i])-hue(pal[i+1]))),1) for i in range(len(pal)-1)]
  results.append({'width':width,'overflow':box['sw']-width,'errors':len(errors),'logo':box['logoLoaded'],'button_count':len(box['buttons']),'rooms':len(box['rooms']),'bullet_adjacent_hue_gaps_degrees':dist,'actions':'PASS','status':'PASS'})
  page.close()
 browser.close()
print(json.dumps(results,indent=2))
